import React from 'react';

const Home = () => {
  return <div><h2>Home</h2><p>Bem-vindo ao Aplicativo de Viagens!</p></div>;
};

export default Home;
