import React from 'react';

const Contato = () => {
  return <div><h2>Contato</h2><p>Entre em contato conosco.</p></div>;
};

export default Contato;
